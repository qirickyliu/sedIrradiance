make_groups <- function(names) {
  if(length(names)%%2 > 0) {
    stop("Uneven number of people")
  }
  shuffled <- matrix(sample(names), ncol = 2)
  return(shuffled)
}

